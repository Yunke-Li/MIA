import os
import numpy as np
import nibabel as nib
import matplotlib.pyplot as plt
import skimage
from skimage import data
from skimage.feature import register_translation
from skimage.transform import warp_polar, rotate
from skimage.util import img_as_float
from skimage import feature
import cv2
from skimage.morphology import convex_hull_image

data_path = "D:\MIA Proj"
example_filename = os.path.join(data_path, 'patient001_frame01.nii.gz')
img = nib.load(example_filename)
header = img.header
img_arr = img.get_fdata()
i = img_arr[:, :, 5]  # 暂时先取第五片
img_slice = np.array(i)
center_x = 100
center_y = 128
roi = i[center_x - 30:center_x + 30, center_y - 30:center_y + 30]


plt.figure()
plt.imshow(i, cmap='gray')
plt.show()

# extended Otsu threshholding
def ExOtsu(image):
    i_min = int(image.min())
    i_max = int(image.max())
    r = i_max - i_min
    (n, bins) = np.histogram(image, bins=r, density=True)
    n = np.append(n, [0])
    G = n * bins
    mG = G.sum()  # 全局平均
    sigma = (bins - mG) ** 2 * n
    sigmaG = sigma.sum()  # 全局方差
    sigmaB = 0
    t1 = 0
    t2 = 0
    for k1 in range(i_min + 1, i_max - 3):
        for k2 in range(k1 + 1, i_max - 1):
            p1 = n[0:k1 - 1].sum()
            p2 = n[k1:k2 - 1].sum()
            p3 = n[k2:i_max].sum()
            m1 = (bins[0:k1 - 1] * n[0:k1 - 1]).sum()  # 类内平均
            m2 = (bins[k1:k2 - 1] * n[k1:k2 - 1]).sum()
            m3 = (bins[k2:i_max] * n[k2:i_max]).sum()
            sigmaB_temp = p1 * (m1 - mG) ** 2 + p2 * (m2 - mG) ** 2 + p3 * (m3 - mG) ** 2  # 类间方差
            if sigmaB_temp >= sigmaB:
                sigmaB = sigmaB_temp
                t1 = k1
                t2 = k2
    return t1, t2


T1, T2 = ExOtsu(roi)

# polar transformation
source = roi
img64_float = source.astype(np.float64)

Mvalue = 30  # radius np.sqrt(((img64_float.shape[0] / 2.0) ** 2.0) + ((img64_float.shape[1] / 2.0) ** 2.0))

polar_image = cv2.linearPolar(img64_float, (img64_float.shape[0] / 2, img64_float.shape[1] / 2), Mvalue,
                              cv2.WARP_FILL_OUTLIERS)  # 中心位置待定

# cartesian_image = cv2.linearPolar(polar_image, (img64_float.shape[0] / 2, img64_float.shape[1] / 2), Mvalue,
#                                   cv2.WARP_INVERSE_MAP)  # 中心位置待定

# cartesian_image = cartesian_image / 200
polar_image = polar_image / 255
cv2.imshow("polar1", polar_image)


# cv2.imshow("polar2", cartesian_image)

# radius = 50  # 待定
# angle = 90
# center = [100, 100]
# image = i
# image = img_as_float(image)
# rotated = rotate(image, angle)
# image_polar = warp_polar(image, radius=radius, multichannel=False)  # center待定
# rotated_polar = warp_polar(rotated, radius=radius, multichannel=False)  # center待定
# fig, axes = plt.subplots(2, 2, figsize=(8, 8))
# ax = axes.ravel()
# ax[0].set_title("Original")
# # ax[0].imshow(image, cmap='gray')
# # ax[1].set_title("Rotated")
# # ax[1].imshow(rotated, cmap='gray')
# # ax[2].set_title("Polar-Transformed Original")
# # ax[2].imshow(image_polar, cmap='gray')
# # ax[3].set_title("Polar-Transformed Rotated")
# # ax[3].imshow(rotated_polar, cmap='gray')
# # plt.show()


# radius region growing + canny edge detector + back transformation
def get8n(x, y, shape):
    out = []
    maxx = shape[1] - 1
    maxy = shape[0] - 1

    # top left
    outx = min(max(x - 1, 0), maxx)
    outy = min(max(y - 1, 0), maxy)
    out.append((outx, outy))

    # top center
    outx = x
    outy = min(max(y - 1, 0), maxy)
    out.append((outx, outy))

    # top right
    outx = min(max(x + 1, 0), maxx)
    outy = min(max(y - 1, 0), maxy)
    out.append((outx, outy))

    # left
    outx = min(max(x - 1, 0), maxx)
    outy = y
    out.append((outx, outy))

    # right
    outx = min(max(x + 1, 0), maxx)
    outy = y
    out.append((outx, outy))

    # bottom left
    outx = min(max(x - 1, 0), maxx)
    outy = min(max(y + 1, 0), maxy)
    out.append((outx, outy))

    # bottom center
    outx = x
    outy = min(max(y + 1, 0), maxy)
    out.append((outx, outy))

    # bottom right
    outx = min(max(x + 1, 0), maxx)
    outy = min(max(y + 1, 0), maxy)
    out.append((outx, outy))

    return out


def region_growing(img, seed):
    list = []
    outimg = np.zeros_like(img)
    list.append((seed[0], seed[1]))
    processed = []
    while len(list) > 0:
        pix = list[0]
        outimg[pix[0], pix[1]] = 255
        for coord in get8n(pix[0], pix[1], img.shape):
            if img[coord[0], coord[1]] != 0:
                outimg[coord[0], coord[1]] = 255
                if not coord in processed:
                    list.append(coord)
                processed.append(coord)
        list.pop(0)

    return outimg


ret, img = cv2.threshold(i, T1, T2, cv2.THRESH_BINARY)  # 阈值要改
# cv2.namedWindow('Input')
# cv2.imshow('Input', img)
seed = [center_x, center_y]  # center要改
region = region_growing(img, seed)
plt.figure()
plt.imshow(region, cmap='gray')
plt.show()

edges = feature.canny(polar_image, sigma=11)
edges64_float = edges.astype(np.float64)
cartesian_edges = cv2.linearPolar(edges64_float, (img64_float.shape[0] / 2, img64_float.shape[1] / 2), Mvalue,
                                  cv2.WARP_INVERSE_MAP)  # 中心位置待定
kernel1 = skimage.morphology.disk(5)
kernel2 = skimage.morphology.disk(3)
img_dilation = skimage.morphology.dilation(cartesian_edges, kernel1)
img_erosion = skimage.morphology.erosion(img_dilation, kernel2)
finaledge = skimage.morphology.skeletonize(img_erosion)
edge_padd = np.zeros(i.shape)
edge_padd[center_x - 30:center_x + 30, center_y - 30:center_y + 30] = finaledge
contour = ((edge_padd + region) >= 1)

# convex hull
convex_hull = convex_hull_image(contour)
plt.figure()
plt.imshow(convex_hull, cmap='gray')
plt.show()
# low-pass filter of FFT (smoothing)
